// ================= PART 5: Mixins =================
mixin AttendanceMixin {
  int attendanceCount = 0;

  void markAttendance() {
    attendanceCount++;
  }
}

class Student with AttendanceMixin {
  String name;

  Student(this.name);
}

void main() {
  print("=== Part 5: Mixins ===");
  
  var student = Student("Eva");
  for (int i = 0; i < 3; i++) {
    student.markAttendance();
  }
  print("${student.name}'s Attendance: ${student.attendanceCount}");
}