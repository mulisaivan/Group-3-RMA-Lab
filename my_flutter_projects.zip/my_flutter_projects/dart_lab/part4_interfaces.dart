// ================= PART 4: Interfaces =================
abstract class Registrable {
  void registerCourse(String courseName);
}

class Student implements Registrable {
  String name;

  Student(this.name);

  @override
  void registerCourse(String courseName) {
    print("$name is registered for $courseName");
  }
}

void main() {
  print("=== Part 4: Interfaces ===");
  
  var student = Student("David");
  student.registerCourse("Computer Science");
}