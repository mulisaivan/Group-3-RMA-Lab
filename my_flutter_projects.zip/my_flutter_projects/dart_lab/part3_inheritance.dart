// ================= PART 3: Inheritance =================
class Person {
  String name = "";
  
  void introduce() {
    print("Hello, I am $name");
  }
}

class Student extends Person {
  Student(String name) {
    this.name = name;
  }
}

void main() {
  print("=== Part 3: Inheritance ===");
  
  var student = Student("Charlie");
  student.introduce();
}