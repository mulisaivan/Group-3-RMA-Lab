// ================= PART 2: Constructors and Classes =================
class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  print("=== Part 2: Constructors and Classes ===");

  // Create object and print
  var student1 = Student("Bob", 22);
  print("Student Name: ${student1.name}, Age: ${student1.age}");
}