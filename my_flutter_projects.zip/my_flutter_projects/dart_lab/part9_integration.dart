// ================= PART 9: Integration Challenge =================
mixin NotificationMixin {
  void notifyRegistration(String studentName, String course) {
    print("Notification: $studentName registered for $course");
  }
}

class Student with NotificationMixin {
  String name;

  Student(this.name);

  void registerCourse(String course) {
    notifyRegistration(name, course);
  }
}

void main() {
  print("=== Part 9: Integration Challenge ===");
  
  var student = Student("Sam");
  student.registerCourse("Physics");
}