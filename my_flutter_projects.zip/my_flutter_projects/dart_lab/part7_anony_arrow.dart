// ================= PART 7: Anonymous and Arrow Functions =================
class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  print("=== Part 7: Anonymous and Arrow Functions ===");

  List<Student> students = [
    Student("Liam", 20),
    Student("Mia", 21),
    Student("Noah", 22),
  ];

  // Q14: Anonymous function to print names
  print("Student Names:");
  students.forEach((student) {
    print(student.name);
  });

  // Q15: Arrow function for greeting
  void greetStudent(String name) => print("Hello, $name! Welcome to class.");
  greetStudent("Olivia");
}