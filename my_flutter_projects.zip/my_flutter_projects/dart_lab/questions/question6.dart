// Q6: Create a class 'Person' with a variable 'name' 
// and a function 'introduce()' that prints the name.

class Person {
  String name = "";
  
  void introduce() {
    print("Hello, I am $name");
  }
}

void main() {
  // Just print confirmation - no object creation required for Q6
  print("Person class created successfully!");
  print("It has a name variable and an introduce() method.");
}