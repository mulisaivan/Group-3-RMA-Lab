void main() {
  // Q1: welcomeMessage function
  void welcomeMessage() {
    print("Welcome to the School Management System!");
  }
  
  // Call the function
  welcomeMessage();
}