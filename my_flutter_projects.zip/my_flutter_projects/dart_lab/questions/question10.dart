// Q10: Create a mixin 'AttendanceMixin' that stores an attendance counter 
// and has a function 'markAttendance()' to increase attendance.

mixin AttendanceMixin {
  int attendanceCount = 0;

  void markAttendance() {
    attendanceCount++;
  }
}

void main() {
  // Just print confirmation - no application required for Q10
  print("AttendanceMixin created successfully!");
  print("It has: attendanceCount variable and markAttendance() method");
}