// Q4: Create a class named Student with name and age, 
// and a constructor to initialize these values.

class Student {
  String name;
  int age;

  // Constructor
  Student(this.name, this.age);
}

void main() {
  // Just print confirmation - no object creation required for Q4
  print("Student class created successfully!");
  print("The constructor takes name and age parameters.");
}