// Q11: Apply 'AttendanceMixin' to 'Student'. 
// Mark attendance 3 times and print the attendance.

mixin AttendanceMixin {
  int attendanceCount = 0;

  void markAttendance() {
    attendanceCount++;
  }
}

class Student with AttendanceMixin {
  String name;

  Student(this.name);
}

void main() {
  // Create Student
  var student = Student("Eva");
  
  // Mark attendance 3 times
  student.markAttendance();
  student.markAttendance();
  student.markAttendance();
  
  // Print the attendance
  print("${student.name}'s Attendance: ${student.attendanceCount}");
}