// Q16: Write an async function 'loadStudents()' 
// that waits 2 seconds and returns the list of students.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

// Async function that waits 2 seconds
Future<List<Student>> loadStudents() async {
  await Future.delayed(Duration(seconds: 2));
  return [
    Student("Paul", 19),
    Student("Quinn", 20),
    Student("Ryan", 21),
  ];
}

void main() async {
  print("Q16: loadStudents() async function created");
  print("This function waits 2 seconds and returns a list of students.");
  print("\nFunction signature: Future<List<Student>> loadStudents()");
  
  // Call it to show it works
  print("\nCalling loadStudents()...");
  var students = await loadStudents();
  print("Students loaded: ${students.length}");
  print("Students: ${students.map((s) => s.name).join(', ')}");
}