// Q13: Create a Map where the key is student ID and value is a 'Student'. 
// Print all student names.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  // Create a Map with student ID as key and Student object as value
  Map<int, Student> studentMap = {
    1001: Student("Ivy", 24),
    1002: Student("Jack", 25),
    1003: Student("Kara", 23),
  };

  // Print all student names
  print("Student Map (ID → Name):");
  print("------------------------");
  studentMap.forEach((id, student) {
    print("ID: $id → Name: ${student.name}");
  });
  
  print("\nTotal students in map: ${studentMap.length}");
}