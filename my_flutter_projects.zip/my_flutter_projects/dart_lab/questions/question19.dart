// Q19: Create a new mixin 'NotificationMixin' that prints a message 
// when a student is registered to a course. Apply it to 'Student'.

mixin NotificationMixin {
  void notifyRegistration(String studentName, String course) {
    print("Notification: $studentName registered for $course");
  }
}

class Student with NotificationMixin {
  String name;

  Student(this.name);

  void registerCourse(String course) {
    notifyRegistration(name, course);
  }
}

void main() {
  // Create Student and register for a course
  var student = Student("Sam");
  student.registerCourse("Physics");
}