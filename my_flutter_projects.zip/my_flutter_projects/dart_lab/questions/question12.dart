// Q12: Create a List storing multiple 'Student' objects. Add 3 students.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  // Create a List storing multiple Student objects
  List<Student> students = [
    Student("Frank", 21),
    Student("Grace", 23),
    Student("Henry", 22),
  ];

  // Print all students in the list
  print("List of Students:");
  print("-----------------");
  for (var i = 0; i < students.length; i++) {
    print("Student ${i + 1}: ${students[i].name}, Age: ${students[i].age}");
  }
  
  print("\nTotal students in list: ${students.length}");
}