// Q8: Create an abstract class 'Registrable' 
// with a function 'registerCourse(String courseName)'.

abstract class Registrable {
  void registerCourse(String courseName);
}

void main() {
  // Just print confirmation - no implementation required for Q8
  print("Registrable abstract class created successfully!");
  print("It has an abstract method: registerCourse(String courseName)");
}