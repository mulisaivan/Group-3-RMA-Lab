// Q7: Make 'Student' inherit from 'Person' 
// and call 'introduce()' from a 'Student' object.

class Person {
  String name = "";
  
  void introduce() {
    print("Hello, I am $name");
  }
}

class Student extends Person {
  Student(String name) {
    this.name = name;
  }
}

void main() {
  // Create Student object and call introduce()
  var student = Student("Charlie");
  student.introduce();
}