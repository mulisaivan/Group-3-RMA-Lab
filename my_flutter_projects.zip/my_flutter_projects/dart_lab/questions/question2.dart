void main() {
  // Q2: Write a function named createStudent that uses named parameters 
  // (name and age) and prints the student details.
  
  void createStudent({required String name, required int age}) {
    print("Student Name: $name, Age: $age");
  }
  
  // Call with named parameters
  createStudent(name: "Alice", age: 20);
}