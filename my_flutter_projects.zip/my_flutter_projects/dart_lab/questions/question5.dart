// Q5: Create an object of Student and print the student's name and age.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  // Create an object of Student
  var student = Student("Bob", 22);
  
  // Print the student's name and age
  print("Student Name: ${student.name}");
  print("Student Age: ${student.age}");
}