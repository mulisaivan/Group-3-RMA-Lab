// Q14: Use an anonymous function to print all student names from the list.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  // Create a List of Students
  List<Student> students = [
    Student("Liam", 20),
    Student("Mia", 21),
    Student("Noah", 22),
  ];

  print("Student Names (using anonymous function):");
  print("----------------------------------------");
  
  // Use anonymous function with forEach
  students.forEach((student) {
    print(student.name);
  });
}