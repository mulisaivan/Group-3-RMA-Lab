// Q17: In main(), call 'loadStudents()', use await, 
// and print the number of students loaded.

class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

// Async function that waits 2 seconds
Future<List<Student>> loadStudents() async {
  print("⏳ Loading students... (waiting 2 seconds)");
  await Future.delayed(Duration(seconds: 2));
  return [
    Student("Paul", 19),
    Student("Quinn", 20),
    Student("Ryan", 21),
  ];
}

void main() async {
  print("=== Q17: Calling loadStudents() with await ===\n");
  
  // Call loadStudents() with await
  var students = await loadStudents();
  
  // Print the number of students loaded
  print("✅ Number of students loaded: ${students.length}");
}