// Q9: Make 'Student' implement 'Registrable' 
// and implement 'registerCourse' to print the student name and course.

abstract class Registrable {
  void registerCourse(String courseName);
}

class Student implements Registrable {
  String name;

  Student(this.name);

  @override
  void registerCourse(String courseName) {
    print("$name is registered for $courseName");
  }
}

void main() {
  // Create Student and call registerCourse
  var student = Student("David");
  student.registerCourse("Computer Science");
}