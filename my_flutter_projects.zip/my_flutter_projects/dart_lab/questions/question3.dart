void main() {
  // Q3: Write a function named createTeacher with one required parameter name 
  // and one optional parameter subject. If subject is not provided, 
  // print "Subject not assigned".
  
  void createTeacher(String name, [String? subject]) {
    if (subject == null) {
      print("Teacher Name: $name, Subject: Subject not assigned");
    } else {
      print("Teacher Name: $name, Subject: $subject");
    }
  }
  
  // Call with and without optional parameter
  createTeacher("Mr. Smith");  // No subject provided
  createTeacher("Ms. Johnson", "Mathematics");  // Subject provided
}