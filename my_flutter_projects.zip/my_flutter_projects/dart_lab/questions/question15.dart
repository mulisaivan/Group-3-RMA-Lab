// Q15: Write an arrow function that takes a student name 
// and prints a greeting message.

void main() {
  // Arrow function definition
  void greetStudent(String name) => print("Hello, $name! Welcome to class.");
  
  print("Arrow Function Greeting:");
  print("------------------------");
  
  // Call the arrow function
  greetStudent("Olivia");
}