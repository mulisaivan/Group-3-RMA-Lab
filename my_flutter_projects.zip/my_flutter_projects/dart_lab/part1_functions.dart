// ================= PART 1: Functions =================
void main() {
  print("=== Part 1: Functions ===");

  // Q1: welcomeMessage
  void welcomeMessage() {
    print("Welcome to the School Management System!");
  }
  welcomeMessage();

  // Q2: createStudent with named parameters
  void createStudent({required String name, required int age}) {
    print("Student Name: $name, Age: $age");
  }
  createStudent(name: "Alice", age: 20);

  // Q3: createTeacher with required and optional parameters
  void createTeacher(String name, [String? subject]) {
    if (subject == null) {
      print("Teacher Name: $name, Subject: Subject not assigned");
    } else {
      print("Teacher Name: $name, Subject: $subject");
    }
  }
  createTeacher("Mr. Smith");
  createTeacher("Ms. Johnson", "Mathematics");
}