// ================= PART 6: Collections =================
class Student {
  String name;
  int age;

  Student(this.name, this.age);
}

void main() {
  print("=== Part 6: Collections ===");

  // Q12: List of Students
  List<Student> students = [
    Student("Frank", 21),
    Student("Grace", 23),
    Student("Henry", 22),
  ];

  print("Student List:");
  for (var s in students) {
    print("${s.name}, ${s.age}");
  }

  // Q13: Map of Students
  Map<int, Student> studentMap = {
    1001: Student("Ivy", 24),
    1002: Student("Jack", 25),
    1003: Student("Kara", 23),
  };

  print("\nStudent Map:");
  studentMap.forEach((id, student) {
    print("ID: $id, Name: ${student.name}");
  });
}