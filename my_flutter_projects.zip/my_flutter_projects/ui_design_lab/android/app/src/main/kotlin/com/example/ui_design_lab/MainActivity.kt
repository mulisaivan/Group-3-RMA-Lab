package com.example.ui_design_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
